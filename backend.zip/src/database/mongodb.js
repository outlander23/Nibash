require("dotenv").config();
const mongoose = require("mongoose");
// const PASSWORD = process.env.PASSWORD;
// const URL = process.env.MONGODB_URL;
// const url = URL.replace("<password>", PASSWORD);
const url = "mongodb+srv://moin:moin46@cluster0.ta4jppn.mongodb.net/nibash?retryWrites=true&w=majority"
const connectDB = async () => {
  try {
    await mongoose.connect(url);
    console.log("Connected to database");
  } catch (e) {
    console.log(e);
  }
};

module.exports = connectDB;