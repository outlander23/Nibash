const express = require("express");
const cartRouter = express.Router();

// cartRouter.route("/").get().post();

module.exports = cartRouter;
