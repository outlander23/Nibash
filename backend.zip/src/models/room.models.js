require("dotenv").config();
const mongoose = require("mongoose");
const { Schema } = mongoose;

const roomSchema = new Schema(
  {
    messId: {
      // Indicates which mess this room belongs to
      type: Schema.Types.ObjectId,
      // You might want to add a reference to the Mess model here if you have one
    },
    capacity: {
      type: Number,
      default: 1,
    },
    rent: {
      type: Number,
      default: 0,
    },
    bookedSeat: {
      // You might want to define the type for bookedSeat
      type:Number,
      default: 0,
    },
  },
  {
    timestamps: true,
  }
);

const Room = mongoose.model("Room", roomSchema);

module.exports = Room;
