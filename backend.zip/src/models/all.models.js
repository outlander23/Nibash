require("dotenv").config();
const mongoose = require("mongoose");
const { Schema } = mongoose;


const roomSchema = new Schema({
  roomNumber: {
    type: String,
    required: true,
    unique: true,
  },
  capacity: {
    type: Number,
    default: 1,
  },
  occupancyStatus: {
    type: String,
    enum: ["free", "occupied"],
    default: "free",
  },
  rent: {
    type: Number,
    required: true,
  },
  
  freeSeats:{
    type:Number,
    default: 0,
  },

  messOwnerId: {
    type: Schema.Types.ObjectId,
    ref: "MessOwner",
  },

});

const Room = mongoose.model("Room", roomSchema);


// Define a schema for Mess (Hostel)
const messSchema = new Schema({
  name: {
    type: String,
    required: true,
  },
  rooms: [
    {
      type: Schema.Types.ObjectId,
      ref: "Room",
    },
  ],
  messOwnerId: {
    type: Schema.Types.ObjectId,
    ref: "MessOwner",
  },
  
});

module.exports = { Washroom, Room, Mess, MessOwner, Mess };
