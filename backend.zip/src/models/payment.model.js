require("dotenv").config();
const mongoose = require("mongoose");
const { Schema } = mongoose;

const paymentSchema = new Schema(
  {
    userId: {
      // Indicates which user made the payment
      type: Schema.Types.ObjectId,
      // You might want to add a reference to the User model here if you have one
    },
    amount: {
      type: Number,
      required: true,
    },
    paymentDate: {
      type: Date,
      default: Date.now,
    },
    roomId:{
        type: Schema.Types.ObjectId
    }
    // You might want to add more fields related to the payment details
  },
  {
    timestamps: true,
  }
);

const Payment = mongoose.model("Payment", paymentSchema);

module.exports = Payment;
